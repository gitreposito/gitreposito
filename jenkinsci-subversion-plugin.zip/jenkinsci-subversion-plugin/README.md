Jenkins Subversion Plugin
=========================

Provides Jenkins integration with [Apache Subversion](http://subversion.apache.org/).

See [Subversion Plugin](https://wiki.jenkins-ci.org/display/JENKINS/Subversion+Plugin) on the Jenkins Wiki for more information.

Canonical Repository
--------------------

The Canonical repository for this plugin is [Subversion](https://svn.jenkins-ci.org/trunk/hudson/plugins/subversion).

Apache, Apache Subversion and Subversion are trademarks of the Apache Software Foundation.
